function showMessage() {
  alert("Hello from Manan's website!");
}
